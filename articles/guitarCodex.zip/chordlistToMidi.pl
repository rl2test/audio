# cd C:\rob\music\jazz\util\GuitarCodex

$nl = "\n";
@arr = ("C", "Db", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B");


#String[] chordListArr = { "major\t major\t 1\t 3\t 5", "5\t     5th\t 1\t 5", "6\t     major 6th\t 1\t 3\t 
#major\t major\t 1\t 3\t 5
#m7+5\t  minor 7th augmented 5th\t 1\t b3\t #5\t b7



$inFile = "chordlist.txt";
$outFile = "chordlistToMidi.txt";

open(FILE, "$inFile");
@data = <FILE>;
close(FILE);

open(FILE, ">$outFile");

foreach $datum(@data) {
	$row = $datum;

	$row = trim($row);


	@arr = split(/\|/, $row);
	for $s(@arr) {
		#print $s . $nl;
		
		$desc = "";
		$intervals = "";
		
		#print FILE "\%\%MIDI chordname maj9   0 4 7  11 14";
		print FILE "\%\%MIDI chordname ";
		
		@chordarr = split(/\\t/, $s);
		$i = 1;
		for $el(@chordarr) {
			print $el . " ";
			if ($i == 1) {
				print FILE $el . " ";	
			} elsif ($i == 2) {
				$desc = $el;
			} else {
				$intervals .= $el . " ";
				print FILE $el . " ";
			}
			
			$i++;
		}
		print FILE "\% " . $desc . " " . $intervals . $nl;
	}

}
		

close(FILE);

print "ok $nl";

#subs ##########################################################################


sub trim {
	my $s = shift;
	$s =~ s/^\s+//;
	$s =~ s/\s+$//;
	return $s;
}
